from database.recipe_manager import (
    RecipeManager
)

from database.database import (
    get_connection
)


class PLCDownloadTagReadinessManager:

    REQUIRED_TAGS = [

        {
            "purpose": "RECIPE_DATA",
            "label": "Recipe Data",
            "expected_type": "REAL",
            "array_required": True,
            "minimum_array_size": 500
        },

        {
            "purpose": "RECIPE_CODE",
            "label": "Recipe Code",
            "expected_type": "STRING",
            "array_required": False,
            "minimum_array_size": None
        },

        {
            "purpose": "DOWNLOAD_ENABLE",
            "label": "Download Enable",
            "expected_type": "BOOL",
            "array_required": False,
            "minimum_array_size": None
        },

        {
            "purpose": "DOWNLOAD_REQUEST",
            "label": "Download Request",
            "expected_type": "BOOL",
            "array_required": False,
            "minimum_array_size": None
        },

        {
            "purpose": "DOWNLOAD_COMPLETE",
            "label": "Download Complete",
            "expected_type": "BOOL",
            "array_required": False,
            "minimum_array_size": None
        }

    ]

    @staticmethod
    def check_readiness(

        recipe_id

    ):

        result = {

            "ready": True,

            "status": "READY",

            "errors": [],

            "warnings": [],

            "tags": []

        }

        recipe = (
            RecipeManager
            .get_recipe_by_id(
                recipe_id
            )
        )

        if not recipe:

            result["ready"] = False

            result["status"] = "BLOCKED"

            result["errors"].append(
                "Recipe Not Found"
            )

            return result

        all_tags = (
            PLCDownloadTagReadinessManager
            .get_tags_for_stage(

                machine_id=recipe[
                    "machine_id"
                ],

                stage_id=recipe[
                    "stage_id"
                ]

            )
        )

        for required in PLCDownloadTagReadinessManager.REQUIRED_TAGS:

            tag = (
                PLCDownloadTagReadinessManager
                .find_tag_for_purpose(

                    all_tags,

                    required["purpose"]

                )
            )

            item = {

                "purpose": required["purpose"],

                "label": required["label"],

                "expected_type": required["expected_type"],

                "array_required": required["array_required"],

                "minimum_array_size": required["minimum_array_size"],

                "configured": tag is not None,

                "ready": True,

                "tag": tag,

                "issues": []

            }

            if not tag:

                item["ready"] = False

                item["issues"].append(
                    f"{required['label']} tag is not configured."
                )

            else:

                PLCDownloadTagReadinessManager.validate_tag(

                    item=item,

                    tag=tag,

                    required=required

                )

            if not item["ready"]:

                result["ready"] = False

                result["errors"].extend(
                    item["issues"]
                )

            result["tags"].append(
                item
            )

        if result["ready"]:

            result["status"] = "READY"

            result["warnings"].append(
                "All required PLC download tags are configured."
            )

        else:

            result["status"] = "BLOCKED"

        return result

    @staticmethod
    def get_tags_for_stage(

        machine_id,

        stage_id

    ):

        conn = get_connection()

        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT *

            FROM plc_tags

            WHERE

                machine_id = ?

                AND stage_id = ?

            ORDER BY
                tag_name
            """,
            (
                machine_id,
                stage_id
            )
        )

        rows = cursor.fetchall()

        conn.close()

        return [

            dict(row)

            for row in rows

        ]

    @staticmethod
    def find_tag_for_purpose(

        tags,

        purpose

    ):

        purpose_upper = purpose.upper()

        for tag in tags:

            tag_purpose = (
                tag.get(
                    "tag_purpose"
                )
                or
                ""
            ).upper()

            tag_type = (
                tag.get(
                    "tag_type"
                )
                or
                ""
            ).upper()

            if tag_purpose == purpose_upper:

                return tag

            if tag_type == purpose_upper:

                return tag

        expected_names = (
            PLCDownloadTagReadinessManager
            .get_expected_names(
                purpose_upper
            )
        )

        for tag in tags:

            tag_name = (
                tag.get(
                    "tag_name"
                )
                or
                ""
            ).upper()

            if tag_name in expected_names:

                return tag

        return None

    @staticmethod
    def validate_tag(

        item,

        tag,

        required

    ):

        tag_type = (
            tag.get(
                "tag_type"
            )
            or
            ""
        ).upper()

        expected_type = (
            required["expected_type"]
            or
            ""
        ).upper()

        if (
            expected_type
            and
            tag_type
            and
            tag_type != expected_type
            and
            tag_type != required["purpose"]
        ):

            item["issues"].append(
                f"Expected type {expected_type}, found {tag_type}."
            )

        if required["array_required"]:

            if tag["is_array"] != 1:

                item["issues"].append(
                    "Tag must be configured as an array."
                )

            array_size = (
                tag["array_size"]
                or
                0
            )

            if array_size < required["minimum_array_size"]:

                item["issues"].append(
                    f"Array size must be at least "
                    f"{required['minimum_array_size']}."
                )

            if (
                tag["array_start_index"] is None
                or
                tag["array_end_index"] is None
            ):

                item["issues"].append(
                    "Array start and end indexes are required."
                )

            elif (
                tag["array_start_index"] > 0
                or
                tag["array_end_index"]
                < required["minimum_array_size"] - 1
            ):

                item["issues"].append(
                    "Array must cover indexes 0 to "
                    f"{required['minimum_array_size'] - 1}."
                )

        else:

            if tag["is_array"] == 1:

                item["issues"].append(
                    "Tag should not be configured as an array."
                )

        if item["issues"]:

            item["ready"] = False

    @staticmethod
    def get_expected_names(

        purpose

    ):

        mapping = {

            "RECIPE_DATA": [
                "CRS_RECIPE_DATA"
            ],

            "RECIPE_CODE": [
                "CRS_RECIPE_CODE"
            ],

            "DOWNLOAD_ENABLE": [
                "CRS_DOWNLOAD_ENABLE"
            ],

            "DOWNLOAD_REQUEST": [
                "CRS_DOWNLOAD_REQUEST"
            ],

            "DOWNLOAD_COMPLETE": [
                "CRS_DOWNLOAD_COMPLETE"
            ]

        }

        return mapping.get(
            purpose,
            []
        )
