from database.recipe_download_eligibility_manager import (
    RecipeDownloadEligibilityManager
)

from database.recipe_manager import (
    RecipeManager
)

from database.recipe_parameter_value_manager import (
    RecipeParameterValueManager
)

from database.recipe_phase_control_manager import (
    RecipePhaseControlManager
)

from database.database import (
    get_connection
)


class PLCDownloadPreparationManager:

    PAYLOAD_SIZE = 500

    @staticmethod
    def get_available_plcs(

        recipe_id

    ):

        recipe = (
            RecipeManager
            .get_recipe_by_id(
                recipe_id
            )
        )

        if not recipe:

            return []

        conn = get_connection()

        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT

                p.*,

                m.machine_code,

                s.stage_type

            FROM plc_registry p

            LEFT JOIN machine_stages s

                ON s.id = p.machine_stage_id

            LEFT JOIN tbm_machines m

                ON m.id = s.machine_id

            WHERE

                p.machine_stage_id = ?

                AND p.active = 1

            ORDER BY
                p.plc_name
            """,
            (
                recipe["stage_id"],
            )
        )

        rows = cursor.fetchall()

        conn.close()

        return [

            dict(row)

            for row in rows

        ]

    @staticmethod
    def dry_run(

        recipe_id,

        plc_id

    ):

        result = {

            "ready": True,

            "errors": [],

            "warnings": [],

            "recipe": None,

            "plc": None,

            "payload_summary": {},

            "phase_summary": {}

        }

        recipe = (
            RecipeManager
            .get_recipe_by_id(
                recipe_id
            )
        )

        if not recipe:

            result["ready"] = False

            result["errors"].append(
                "Recipe Not Found"
            )

            return result

        result["recipe"] = recipe

        eligibility = (
            RecipeDownloadEligibilityManager
            .check_eligibility(
                recipe_id
            )
        )

        if not eligibility["eligible"]:

            result["ready"] = False

            result["errors"].extend(
                eligibility["errors"]
            )

        plc = (
            PLCDownloadPreparationManager
            .get_plc_for_recipe(
                recipe,
                plc_id
            )
        )

        if not plc:

            result["ready"] = False

            result["errors"].append(
                "Selected PLC is not active for this recipe stage."
            )

        else:

            result["plc"] = plc

        values = (
            RecipeParameterValueManager
            .get_recipe_values(
                recipe_id
            )
        )

        used_indexes = set()

        duplicate_indexes = []

        missing_indexes = []

        out_of_range_indexes = []

        mapped_count = 0

        non_zero_count = 0

        for row in values:

            plc_index = row[
                "plc_array_index"
            ]

            if plc_index is None:

                missing_indexes.append(
                    row["tag_index"]
                )

                continue

            try:

                plc_index = int(
                    plc_index
                )

            except Exception:

                out_of_range_indexes.append(
                    row["tag_index"]
                )

                continue

            if (
                plc_index < 0
                or
                plc_index >= PLCDownloadPreparationManager.PAYLOAD_SIZE
            ):

                out_of_range_indexes.append(
                    row["tag_index"]
                )

                continue

            if plc_index in used_indexes:

                duplicate_indexes.append(
                    plc_index
                )

            used_indexes.add(
                plc_index
            )

            mapped_count += 1

            if float(
                row["parameter_value"]
                or
                0
            ) != 0:

                non_zero_count += 1

        if missing_indexes:

            result["ready"] = False

            result["errors"].append(
                f"{len(missing_indexes)} parameters have no PLC array index."
            )

        if out_of_range_indexes:

            result["ready"] = False

            result["errors"].append(
                f"{len(out_of_range_indexes)} parameters have invalid "
                f"PLC array index."
            )

        if duplicate_indexes:

            result["ready"] = False

            result["errors"].append(
                "Duplicate PLC array indexes found: "
                + ", ".join(
                    [
                        str(index)
                        for index in sorted(
                            set(duplicate_indexes)
                        )
                    ][:10]
                )
            )

        if not values:

            result["ready"] = False

            result["errors"].append(
                "No recipe parameter values found."
            )

        phase_rows = (
            RecipePhaseControlManager
            .get_recipe_phase_control(
                recipe_id
            )
        )

        result["payload_summary"] = {

            "payload_size":
            PLCDownloadPreparationManager.PAYLOAD_SIZE,

            "total_parameters":
            len(values),

            "mapped_parameters":
            mapped_count,

            "non_zero_values":
            non_zero_count,

            "minimum_plc_array_index":
            min(used_indexes)
            if used_indexes
            else
            "-",

            "maximum_plc_array_index":
            max(used_indexes)
            if used_indexes
            else
            "-"

        }

        result["phase_summary"] = {

            "total_phase_rows":
            len(phase_rows),

            "ready_phase_rows":
            len(
                [
                    row
                    for row in phase_rows
                    if row["phase_control_id"]
                    and row["sequence_no"] is not None
                ]
            )

        }

        if result["ready"]:

            result["warnings"].append(
                "Dry run passed. Real PLC write remains disabled "
                "until final download workflow is approved."
            )

        return result

    @staticmethod
    def get_plc_for_recipe(

        recipe,

        plc_id

    ):

        conn = get_connection()

        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT

                p.*,

                m.machine_code,

                s.stage_type

            FROM plc_registry p

            LEFT JOIN machine_stages s

                ON s.id = p.machine_stage_id

            LEFT JOIN tbm_machines m

                ON m.id = s.machine_id

            WHERE

                p.id = ?

                AND p.machine_stage_id = ?

                AND p.active = 1
            """,
            (
                plc_id,
                recipe["stage_id"]
            )
        )

        row = cursor.fetchone()

        conn.close()

        if row:

            return dict(row)

        return None
